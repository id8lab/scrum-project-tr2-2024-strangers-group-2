# Constants like screen dimensions, tile sizes, colors, etc.
ROWS = 16
COLS = 150
TILE_SIZE = 50
screen_width = 1400
screen_height = 700
TILE_TYPES = 21
